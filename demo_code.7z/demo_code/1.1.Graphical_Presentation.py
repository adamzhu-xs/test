import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 


iris = pd.read_csv('data/iris.csv')

print("-----------------count---------------")
print(iris.iloc[:, 0:4].count())
print("-----------------five number summary---------------")
print(iris.iloc[:, 0:4].describe())
print("-----------------five number summary based on group ---------------")
grouped1 = iris.groupby('Name') #single column 
print(grouped1.describe())

print("-----------------box plot---------------")
import seaborn as sns
g = sns.factorplot(x="Name", y="PetalLength", hue="Name" ,data=iris.iloc[:,0:5], kind="box", palette="PRGn",aspect=2.25)
g.set(ylim=(0, 10))
plt.show()




print("-----------------violin plot---------------")
## violin plot 
import seaborn as sns
#x vs y and hue as 'by' like parameter , could be None 
#kind : {point, bar, count, box, violin, strip}
g = sns.factorplot(x="Name", y="PetalLength", hue="Name" ,data=iris.iloc[:,0:5], kind="violin", palette="PRGn",aspect=2.25)
g.set(ylim=(0, 10))

plt.show()