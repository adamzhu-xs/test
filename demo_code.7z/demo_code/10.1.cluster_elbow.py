print("""
The elbow method to help data scientists select the optimal number 
of clusters by fitting the model with a range of values for K. 
If the line chart resembles an arm, then the 'elbow' (the point of inflection on the curve) 
is a good indication that the underlying model fits best at that point.

Also displays the amount of time to train the clustering model per K 
as a dashed green line, 

It is important to remember that the 'elbow' method does not work well 
if the data is not very clustered. 
In this case, you might see a smooth curve and the optimal value of K 
will be unclear.

""")



#By default, the scoring parameter metric is set to distortion, 
#which computes the sum of squared distances from each point to 
#its assigned center. 
#However, two other metrics can also be used with the KElbowVisualizer 
#– silhouette and calinski_harabaz. 
#The silhouette score calculates the mean Silhouette Coefficient 
#of all samples, while the calinski_harabaz score computes the ratio 
#of dispersion between and within clusters.
from sklearn.datasets import make_blobs

# Create synthetic dataset with 8 random clusters
X, y = make_blobs(centers=8, n_features=12, shuffle=True, random_state=42)

from sklearn.cluster import KMeans
from yellowbrick.cluster import KElbowVisualizer

# Instantiate the clustering model and visualizer
model = KMeans()
visualizer = KElbowVisualizer(model, k=(4,12))

visualizer.fit(X)    # Fit the data to the visualizer
visualizer.poof()    # Draw/show/poof the data

